class VisitorsController < ApplicationController
	def about
	end

	def blog
	end

	def contact
	end

	def home 
	end
end
